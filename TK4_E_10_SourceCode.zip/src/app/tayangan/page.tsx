import { TayanganModule } from "@/components/modules/TayanganModule";

const TayanganPage = () => <TayanganModule />;

export default TayanganPage